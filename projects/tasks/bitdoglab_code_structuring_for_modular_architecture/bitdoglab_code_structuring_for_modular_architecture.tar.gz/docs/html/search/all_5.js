var searchData=
[
  ['⚠_20disclaimer_0',['⚠ Disclaimer',['../index.html',1,'']]]
];
